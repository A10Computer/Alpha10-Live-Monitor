# Alpha10 Live Monitor

Schlanker Live-System-Monitor für Windows – CPU, RAM, GPU, Netzwerk, Datenträger und Prozesse in Echtzeit, in einem modernen Dark-Theme-Dashboard.

Komplett in **reinem Python** (tkinter + ctypes) gebaut, **ganz ohne Drittanbieter-Pakete**.

## Features

- **Live-Dashboard**: CPU-Gesamtauslastung, Kernanzeige inkl. P-/E-/H-Kern-Markierung bei unterstützten Hybrid-CPUs
- **Arbeitsspeicher**: Belegung, Verfügbarkeit, Größe der Auslagerungsdatei
- **GPU**: Kartenname, live VRAM-Nutzung und Auslastung (native Windows-Performance-Counter, dieselbe Quelle wie der Task-Manager-GPU-Tab)
- **Netzwerk**: Live-Graph mit Adaptername und aktuellem Durchsatz
- **Datenträger**: Übersicht über alle Laufwerke inkl. Belegung
- **Top-Prozesse**: sortierbar nach CPU/RAM, mit Ein-Klick-Beenden-Funktion
- **Mini-Modus**: kompaktes, halbtransparentes Always-on-Top-Widget mit Sparkline-Graph
- **Tray-Modus**: dezentes Monitoring im Hintergrund
- **Zwischenablage-Anzeige**: Typ & Größe des aktuellen Inhalts
- Zwei Themes (Cool/Warm), Session-Spitzenwerte, persistente Einstellungen
- **Deutsch & Englisch**: automatische Spracherkennung anhand der Windows-Sprache, jederzeit per Flaggen-Button umschaltbar

## Voraussetzungen

- Windows 10 oder Windows 11
- Keine Installation nötig – die fertige EXE läuft eigenständig, keine Admin-Rechte erforderlich

## Nutzung

Fertige EXE herunterladen und starten.

## Datenschutz

Alpha10 Live Monitor liest ausschließlich lokal auf diesem Gerät: Prozessor-, Arbeitsspeicher-, GPU- und Netzwerkauslastung, Festplattenbelegung, Namen laufender Prozesse sowie Typ und Größe des Zwischenablage-Inhalts (nicht der Inhalt selbst). Es werden keinerlei Daten gespeichert, protokolliert oder über das Internet übertragen – das Programm baut keine Verbindung zu Servern auf.

Eine kleine Einstellungsdatei (Design, Sprache, Sortierung, Mini-Fenster-Position) wird ausschließlich im eigenen Windows-Nutzerprofil abgelegt – und zwar nur, wenn du das beim Beenden des Programms in einem eigenen Dialog ausdrücklich bestätigst. Während der laufenden Sitzung wird nichts geschrieben; lehnst du beim Beenden ab, bleibt es bei keiner Datei. Über die Option „Diese Frage nicht mehr stellen" lässt sich diese Abfrage dauerhaft abschalten – die dann gewählte Standardantwort (speichern oder nicht) wird für zukünftige Sitzungen übernommen.

## Haftungsausschluss

Die Nutzung dieser Software erfolgt vollständig auf eigene Verantwortung. Trotz sorgfältiger Entwicklung übernehmen die Autoren keine Gewähr für Fehlerfreiheit, durchgehende Verfügbarkeit oder Eignung für einen bestimmten Zweck.

Für Schäden, Datenverluste oder sonstige Nachteile, die aus der Nutzung dieser Software entstehen – einschließlich, aber nicht beschränkt auf die Prozess-Beenden-Funktion, die laufende Prozesse unwiderruflich terminiert – wird, soweit gesetzlich zulässig, keine Haftung übernommen.

Dieses Tool ist **kein** Ersatz für professionelle System- oder Sicherheitssoftware. Es liest ausschließlich Systemzustände aus und nimmt außer dem Beenden von Prozessen auf ausdrücklichen Nutzerwunsch keine Änderungen am System vor.

## Lizenz

© 2026 Björn Scherf – Alle Rechte vorbehalten. Kostenlose Nutzung auf eigenes Risiko. Keine Weiterverbreitung oder kommerzielle Nutzung ohne Zustimmung.

## Kontakt

Fragen, Fehler melden oder Feedback: **[alpha10.de](https://alpha10.de)**
